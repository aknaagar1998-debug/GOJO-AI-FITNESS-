package com.gojoai.fitness;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.Gravity;
import android.widget.*;
import android.text.InputType;
import java.util.ArrayList;

public class MainActivity extends Activity {
    int BG=Color.rgb(9,10,18), CARD=Color.rgb(25,27,42), PURPLE=Color.rgb(155,123,255), WHITE=Color.WHITE;
    LinearLayout root, content;
    String name="Athlete", goal="General fitness", place="Home";
    int water=0;
    ArrayList<String> foods=new ArrayList<>(), workouts=new ArrayList<>();

    public void onCreate(Bundle b){super.onCreate(b); showWelcome();}
    void setup(String title){
        root=new LinearLayout(this); root.setOrientation(1); root.setPadding(18,20,18,12); root.setBackgroundColor(BG); setContentView(root);
        TextView brand=txt("GOJO AI FITNESS",13,true); brand.setTextColor(PURPLE); root.addView(brand);
        TextView h=txt(title,25,true); h.setPadding(0,12,0,14); root.addView(h);
        ScrollView sc=new ScrollView(this); root.addView(sc,new LinearLayout.LayoutParams(-1,0,1));
        content=new LinearLayout(this); content.setOrientation(1); sc.addView(content);
        LinearLayout nav=new LinearLayout(this); nav.setGravity(Gravity.CENTER); root.addView(nav);
        navButton(nav,"Home",this::showDashboard); navButton(nav,"Workout",this::showWorkout);
        navButton(nav,"Food",this::showNutrition); navButton(nav,"Profile",this::showProfile);
    }
    TextView txt(String s,int size,boolean bold){TextView t=new TextView(this);t.setText(s);t.setTextColor(WHITE);t.setTextSize(size);if(bold)t.setTypeface(null,Typeface.BOLD);t.setPadding(0,5,0,7);return t;}
    void navButton(LinearLayout row,String s,Runnable r){Button b=new Button(this);b.setText(s);b.setTextSize(10);b.setAllCaps(false);b.setTextColor(WHITE);b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(CARD));row.addView(b,new LinearLayout.LayoutParams(0,48,1));b.setOnClickListener(v->r.run());}
    void card(String title,String body){LinearLayout box=new LinearLayout(this);box.setOrientation(1);box.setPadding(15,12,15,12);box.setBackgroundColor(CARD);TextView h=txt(title,16,true);h.setTextColor(PURPLE);box.addView(h);box.addView(txt(body,14,false));LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);lp.setMargins(0,0,0,11);content.addView(box,lp);}
    void button(String s,Runnable r){Button b=new Button(this);b.setText(s);b.setAllCaps(false);b.setTextColor(WHITE);b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(PURPLE));LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);lp.setMargins(0,4,0,9);content.addView(b,lp);b.setOnClickListener(v->r.run());}
    EditText field(String hint,int type){EditText e=new EditText(this);e.setHint(hint);e.setHintTextColor(Color.LTGRAY);e.setTextColor(WHITE);e.setSingleLine(true);e.setInputType(type);e.setBackgroundTintList(android.content.res.ColorStateList.valueOf(PURPLE));content.addView(e);return e;}
    void showWelcome(){setup("Your fitness journey starts here");card("Train smart. Stay consistent.","A simple fitness companion for workouts, balanced meals and healthy habits.");button("Create my profile",this::showOnboarding);button("Explore demo dashboard",this::showDashboard);content.addView(txt("Starter version: data is saved on this device. Real Firebase login and cloud sync will be connected in the next stage.",12,false));}
    void showOnboarding(){
        setup("Create your profile"); EditText n=field("First name",InputType.TYPE_CLASS_TEXT); EditText a=field("Age",InputType.TYPE_CLASS_NUMBER);
        Spinner g=new Spinner(this);String[] goals={"General fitness","Strength","Stamina","Mobility","Muscle development"};g.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,goals));content.addView(txt("Main goal",14,true));content.addView(g);
        Spinner p=new Spinner(this);p.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,new String[]{"Home","Gym"}));content.addView(txt("Workout location",14,true));content.addView(p);
        button("Save profile",()->{if(n.getText().toString().trim().isEmpty()||a.getText().toString().trim().isEmpty()){toast("Enter your name and age");return;}int age;try{age=Integer.parseInt(a.getText().toString());}catch(Exception ex){age=0;}if(age<13||age>100){toast("Enter a valid age");return;}name=n.getText().toString().trim();goal=g.getSelectedItem().toString();place=p.getSelectedItem().toString();getPreferences(0).edit().putString("name",name).putString("goal",goal).putString("place",place).apply();showDashboard();});
    }
    void showDashboard(){name=getPreferences(0).getString("name",name);goal=getPreferences(0).getString("goal",goal);place=getPreferences(0).getString("place",place);setup("Welcome, "+name);card("TODAY'S FOCUS",goal+"\nWorkout location: "+place+"\nKeep it comfortable and consistent.");card("WORKOUT","Choose Workout to see your starter session.");card("NUTRITION","Build balanced meals with regular food, fruits, vegetables and protein sources.");card("WATER","Logged today: "+water+" ml");button("Add 250 ml water",()->{water+=250;showDashboard();});button("Complete profile",this::showOnboarding);}
    void showWorkout(){setup("Workout planner");card("Warm-up","5–8 minutes of easy movement and gentle mobility.");String[] moves=place.equals("Gym")?new String[]{"Bodyweight squat — 2 × 8–10","Incline push-up or chest press — 2 × 8–10","Seated row or band row — 2 × 8–10","Easy walk — 5–10 minutes"}:new String[]{"Chair squat — 2 × 8–10","Wall push-up — 2 × 8–10","Glute bridge — 2 × 8–10","Easy march in place — 5 minutes"};for(String m:moves){card("Exercise",m+"\nRest as needed. Stop if you feel pain or unwell.");button("Mark complete",()->{workouts.add(m);toast("Exercise logged");});}card("Recovery","Take rest days and increase difficulty gradually.");card("History",workouts.size()+" exercise entries logged.");}
    void showNutrition(){setup("Nutrition & food diary");card("Daily guide","Eat regular balanced meals with grains, protein foods, fruits or vegetables, and healthy fats. Eat enough to support growth and activity.");EditText f=field("Meal / food name",InputType.TYPE_CLASS_TEXT);Spinner c=new Spinner(this);c.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,new String[]{"Breakfast","Lunch","Snack","Dinner"}));content.addView(txt("Meal type",14,true));content.addView(c);button("Add food entry",()->{String v=f.getText().toString().trim();if(v.isEmpty()){toast("Enter a food name");return;}foods.add(c.getSelectedItem()+": "+v);showNutrition();});card("Today's entries",foods.isEmpty()?"No meals added yet.":android.text.TextUtils.join("\n",foods));card("Note","Nutrition values are not calculated in this starter version. Avoid strict calorie targets or crash diets.");}
    void showProfile(){setup("Your profile");card("Profile","Name: "+getPreferences(0).getString("name","Not set")+"\nGoal: "+getPreferences(0).getString("goal",goal)+"\nWorkout location: "+getPreferences(0).getString("place",place));button("Edit profile",this::showOnboarding);button("Reset local profile",()->{getPreferences(0).edit().clear().apply();name="Athlete";goal="General fitness";place="Home";water=0;foods.clear();workouts.clear();showWelcome();});card("Coming next","Firebase email login, cloud sync, AI-generated plans and progress charts need configuration and testing.");}
    void toast(String s){Toast.makeText(this,s,Toast.LENGTH_SHORT).show();}
}
