# GOJO AI FITNESS — Android starter project

Included now:
- Native Android Java app
- Dark dashboard
- Basic profile onboarding
- Starter home/gym workout suggestions
- Simple food diary
- Water tracker
- Local profile preferences

Not implemented yet: real Firebase email login, cloud sync, AI API, automatic nutrition calculations, advanced progress charts. This starter does not claim those features are active.

## Build from an Android phone using GitHub Actions
1. Sign in to GitHub in your phone browser and create a repository named `GOJO-AI-FITNESS`.
2. Upload the contents of this project into the repository (upload the files/folders, not the ZIP as one file).
3. Open the repository's Actions tab. Enable Actions if prompted.
4. The workflow runs on pushes to `main`, or start it with Run workflow.
5. Open a completed workflow run and download the artifact `GOJO-AI-FITNESS-debug-apk`.
6. Extract the artifact ZIP and install `app-debug.apk`. Android may ask permission to install apps from your browser/files app.

## Firebase next step
Create a Firebase project, add an Android app with package name `com.gojoai.fitness`, download `google-services.json`, and put it in `app/google-services.json`. The Gradle file is prepared to add Firebase Auth and Firestore dependencies when that file exists. The actual login screens, Firestore operations and security rules still need to be implemented and tested.
