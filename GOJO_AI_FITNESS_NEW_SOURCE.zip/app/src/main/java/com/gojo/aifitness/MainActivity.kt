package com.gojo.aifitness

import android.graphics.Bitmap
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.layout.ContentScale
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import kotlinx.coroutines.delay
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.label.ImageLabeling
import com.google.mlkit.vision.label.defaults.ImageLabelerOptions

private val Bg = Color(0xFF080610)
private val Panel = Color(0xFF171126)
private val Purple = Color(0xFFB45CFF)
private val Pink = Color(0xFFED4DFF)
private val Cyan = Color(0xFF49DDF5)
private val Muted = Color(0xFFB9AEC9)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = android.graphics.Color.rgb(8,6,16)
        window.navigationBarColor = android.graphics.Color.rgb(8,6,16)
        setContent { GojoApp() }
    }
}

@Composable
fun GojoApp() {
    var splash by remember { mutableStateOf(true) }
    LaunchedEffect(Unit) { delay(1700); splash = false }
    val context = androidx.compose.ui.platform.LocalContext.current
    val prefs = remember { context.getSharedPreferences("gojo_data", 0) }
    var tab by remember { mutableStateOf("Home") }
    var workouts by remember { mutableIntStateOf(prefs.getInt("workouts", 0)) }
    var calories by remember { mutableIntStateOf(prefs.getInt("calories", 0)) }
    var protein by remember { mutableIntStateOf(prefs.getInt("protein", 0)) }
    var carbs by remember { mutableIntStateOf(prefs.getInt("carbs", 0)) }
    var fats by remember { mutableIntStateOf(prefs.getInt("fats", 0)) }
    var water by remember { mutableIntStateOf(prefs.getInt("water", 0)) }
    var scannedLabels by remember { mutableStateOf(listOf<String>()) }
    var scanMessage by remember { mutableStateOf("Take a meal photo to identify visible food labels.") }
    var bitmap by remember { mutableStateOf<Bitmap?>(null) }
    var mealCalories by remember { mutableStateOf("450") }
    var mealProtein by remember { mutableStateOf("25") }
    var mealCarbs by remember { mutableStateOf("55") }
    var mealFats by remember { mutableStateOf("14") }
    var showMealEditor by remember { mutableStateOf(false) }

    fun save() { prefs.edit().putInt("workouts", workouts).putInt("calories", calories).putInt("protein", protein).putInt("carbs", carbs).putInt("fats", fats).putInt("water", water).apply() }

    val camera = rememberLauncherForActivityResult(ActivityResultContracts.TakePicturePreview()) { image ->
        if (image != null) {
            bitmap = image
            scanMessage = "Analyzing visible food labels…"
            val input = InputImage.fromBitmap(image, 0)
            val labeler = ImageLabeling.getClient(ImageLabelerOptions.DEFAULT_OPTIONS)
            labeler.process(input).addOnSuccessListener { labels ->
                scannedLabels = labels.sortedByDescending { it.confidence }.take(8).map { "${it.text} (${(it.confidence * 100).toInt()}%)" }
                scanMessage = if (scannedLabels.isEmpty()) "No clear labels found. Please enter foods manually." else "Possible matches — check these before adding your meal."
                showMealEditor = true
            }.addOnFailureListener { scanMessage = "Could not analyze photo. You can still enter meal details manually."; showMealEditor = true }
        } else scanMessage = "Camera cancelled. Tap Scan Meal to try again."
    }

    if (splash) { SplashScreen(); return }

    MaterialTheme(colorScheme = darkColorScheme(primary = Purple, secondary = Cyan, background = Bg, surface = Panel, onBackground = Color.White, onSurface = Color.White)) {
        Scaffold(containerColor = Bg, bottomBar = {
            NavigationBar(containerColor = Color(0xFF100B1B), contentColor = Color.White) {
                listOf("Home" to "⌂", "Workout" to "✦", "Nutrition" to "◉", "Progress" to "▥", "Profile" to "♙").forEach { (name, icon) ->
                    NavigationBarItem(selected = tab == name, onClick = { tab = name }, icon = { Text(icon, fontSize = 20.sp) }, label = { Text(name, fontSize = 10.sp) }, colors = NavigationBarItemDefaults.colors(selectedIconColor = Purple, selectedTextColor = Purple, indicatorColor = Color(0xFF302044), unselectedTextColor = Muted))
                }
            }
        }) { padding ->
            Box(Modifier.fillMaxSize().padding(padding)) {
                when (tab) {
                    "Home" -> HomeScreen(workouts, calories, protein, water) { tab = it }
                    "Workout" -> WorkoutScreen(onComplete = { workouts++; save() })
                    "Nutrition" -> NutritionScreen(calories, protein, carbs, fats, water, bitmap, scanMessage, scannedLabels, onScan = { camera.launch(null) }, onWater = { water++; save() }, onAdd = { c,p,cb,f -> calories += c; protein += p; carbs += cb; fats += f; save(); showMealEditor = false; tab = "Nutrition" })
                    "Progress" -> ProgressScreen(workouts, calories)
                    else -> ProfileScreen(workouts)
                }
                if (showMealEditor) AlertDialog(onDismissRequest = { showMealEditor = false }, containerColor = Panel, title = { Text("Confirm meal estimate", color = Color.White) }, text = {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("Detected labels are suggestions, not guaranteed ingredients:", color = Muted, fontSize = 12.sp)
                        Text(scannedLabels.joinToString(" • ").ifBlank { "No labels detected" }, color = Color.White, fontSize = 12.sp)
                        MacroInput("Calories (kcal)", mealCalories) { mealCalories = it }
                        MacroInput("Protein (g)", mealProtein) { mealProtein = it }
                        MacroInput("Carbs (g)", mealCarbs) { mealCarbs = it }
                        MacroInput("Fat (g)", mealFats) { mealFats = it }
                    }
                }, confirmButton = { TextButton(onClick = { calories += mealCalories.toIntOrNull() ?: 0; protein += mealProtein.toIntOrNull() ?: 0; carbs += mealCarbs.toIntOrNull() ?: 0; fats += mealFats.toIntOrNull() ?: 0; save(); showMealEditor = false }) { Text("Add to diary", color = Purple) } }, dismissButton = { TextButton(onClick = { showMealEditor = false }) { Text("Cancel", color = Muted) } })
            }
        }
    }
}

@Composable fun Page(title: String, subtitle: String? = null, content: @Composable ColumnScope.() -> Unit) {
    LazyColumn(Modifier.fillMaxSize().background(Bg).padding(horizontal = 18.dp), contentPadding = PaddingValues(top = 22.dp, bottom = 24.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        item { Column { Text(title, color = Color.White, fontSize = 26.sp, fontWeight = FontWeight.ExtraBold); if (subtitle != null) Text(subtitle, color = Muted, fontSize = 13.sp) } }
        item { Column(content = content) }
    }
}
@Composable fun PanelCard(content: @Composable ColumnScope.() -> Unit) { Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(20.dp), modifier = Modifier.fillMaxWidth()) { Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp), content = content) } }
@Composable fun Stat(label: String, value: String, color: Color = Purple) { Column(Modifier.background(Color(0xFF211633), RoundedCornerShape(14.dp)).padding(12.dp)) { Text(value, color = color, fontSize = 22.sp, fontWeight = FontWeight.Bold); Text(label, color = Muted, fontSize = 11.sp) } }
@Composable fun ActionButton(text: String, onClick: () -> Unit) { Button(onClick = onClick, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Purple, contentColor = Color.Black), shape = RoundedCornerShape(14.dp)) { Text(text, fontWeight = FontWeight.Bold) } }

@Composable fun HomeScreen(workouts: Int, calories: Int, protein: Int, water: Int, go: (String) -> Unit) = Page("GOJO AI FITNESS", "Train • Track • Transform") {
    PanelCard { Text("WELCOME, FIGHTER ⚡", color = Purple, fontWeight = FontWeight.Bold); Text("Stronger than yesterday.", fontSize = 22.sp, fontWeight = FontWeight.Bold); Text("Your infinity journey starts today.", color = Muted) }
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) { Box(Modifier.weight(1f)) { Stat("Calories eaten", "$calories kcal", Pink) }; Box(Modifier.weight(1f)) { Stat("Workouts", "$workouts", Cyan) }; Box(Modifier.weight(1f)) { Stat("Protein", "${protein}g", Purple) } }
    PanelCard { Text("DAILY GOALS", color = Purple, fontWeight = FontWeight.Bold); Text("Water: ${water}/8 glasses", color = Color.White); LinearProgressIndicator(progress = { (water / 8f).coerceIn(0f,1f) }, color = Cyan, trackColor = Color(0xFF342640), modifier = Modifier.fillMaxWidth()); Text("Quick access", color = Muted); ActionButton("Start Cursed Energy Workout") { go("Workout") }; OutlinedButton(onClick = { go("Nutrition") }, modifier = Modifier.fillMaxWidth()) { Text("Open Infinity Fuel Nutrition") } }
}

@Composable fun WorkoutScreen(onComplete: () -> Unit) = Page("CURSED ENERGY", "Choose a movement. Track your sets and reps.") {
    val exercises = listOf("Push-ups" to "3 sets • 12 reps", "Squats" to "4 sets • 15 reps", "Plank" to "3 sets • 45 sec", "Lunges" to "3 sets • 12 each leg", "Jumping jacks" to "3 sets • 30 sec")
    exercises.forEachIndexed { i, pair -> PanelCard { Row(verticalAlignment = Alignment.CenterVertically) { Text(listOf("💪","🦵","⚡","🏋️","🔥")[i], fontSize = 28.sp); Spacer(Modifier.width(12.dp)); Column(Modifier.weight(1f)) { Text(pair.first, fontWeight = FontWeight.Bold); Text(pair.second, color = Muted, fontSize = 12.sp) }; Text("GO", color = Purple, fontWeight = FontWeight.Black) } } }
    PanelCard { Text("SESSION COMPLETE?", color = Purple, fontWeight = FontWeight.Bold); Text("Mark a workout complete to update your progress.", color = Muted, fontSize = 12.sp); ActionButton("Complete workout ✓", onComplete) }
}

@Composable fun NutritionScreen(cal: Int, protein: Int, carbs: Int, fats: Int, water: Int, bitmap: Bitmap?, message: String, labels: List<String>, onScan: () -> Unit, onWater: () -> Unit, onAdd: (Int,Int,Int,Int) -> Unit) = Page("INFINITY FUEL", "Fuel your body. Confirm every estimate.") {
    PanelCard { Text("DAILY ENERGY", color = Purple, fontWeight = FontWeight.Bold); Text("$cal kcal", fontSize = 34.sp, fontWeight = FontWeight.ExtraBold, color = Color.White); Text("Illustrative target: 2,200 kcal", color = Muted, fontSize = 12.sp); Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) { Box(Modifier.weight(1f)) { Stat("Protein", "${protein}g", Cyan) }; Box(Modifier.weight(1f)) { Stat("Carbs", "${carbs}g", Pink) }; Box(Modifier.weight(1f)) { Stat("Fat", "${fats}g", Purple) } } }
    PanelCard { Text("AI MEAL SCANNER", color = Purple, fontWeight = FontWeight.Bold); Text("Take a photo. On-device ML suggests visible labels. Confirm ingredients and portion/macros yourself.", color = Muted, fontSize = 12.sp); if (bitmap != null) Image(bitmap.asImageBitmap(), null, Modifier.fillMaxWidth().height(150.dp)); Text(message, color = Color.White, fontSize = 12.sp); if (labels.isNotEmpty()) Text(labels.joinToString(" • "), color = Cyan, fontSize = 12.sp); ActionButton("📷  SCAN MY MEAL") { onScan() } }
    PanelCard { Text("HYDRATION", color = Purple, fontWeight = FontWeight.Bold); Text("$water / 8 glasses", color = Color.White); LinearProgressIndicator(progress = { (water/8f).coerceIn(0f,1f) }, color = Cyan, modifier = Modifier.fillMaxWidth()); OutlinedButton(onClick = onWater, modifier = Modifier.fillMaxWidth()) { Text("+ Add one glass", color = Cyan) } }
    PanelCard { Text("QUICK MANUAL MEAL", color = Purple, fontWeight = FontWeight.Bold); Text("Add a simple sample meal estimate (you can edit values in the scan dialog after scanning).", color = Muted, fontSize = 12.sp); ActionButton("Add sample meal: 450 kcal") { onAdd(450,25,55,14) } }
}

@Composable fun ProgressScreen(workouts: Int, calories: Int) = Page("YOUR PROGRESS", "Small steps. Infinite growth.") {
    PanelCard { Text("WORKOUTS COMPLETED", color = Purple, fontWeight = FontWeight.Bold); Text("$workouts", fontSize = 38.sp, color = Color.White, fontWeight = FontWeight.ExtraBold); Text("Total sessions on this device", color = Muted, fontSize = 12.sp) }
    PanelCard { Text("ACTIVITY TREND", color = Purple, fontWeight = FontWeight.Bold); Canvas(Modifier.fillMaxWidth().height(150.dp)) { val values = listOf(.22f,.38f,.31f,.55f,.48f,.72f,.84f); val step = size.width/(values.size-1); val pts = values.mapIndexed { i,v -> Offset(i*step, size.height*(1-v)) }; for (i in 0 until pts.lastIndex) drawLine(Purple, pts[i], pts[i+1], strokeWidth=5f); pts.forEach { drawCircle(Cyan, radius=5f, center=it) } }; Text("Illustrative trend line; future entries will populate real history.", color = Muted, fontSize = 11.sp) }
    PanelCard { Text("TODAY", color = Purple, fontWeight = FontWeight.Bold); Text("Calories logged: $calories kcal", color = Color.White) }
}

@Composable fun ProfileScreen(workouts: Int) = Page("FIGHTER PROFILE", "Your training identity") {
    PanelCard { Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) { Column(horizontalAlignment = Alignment.CenterHorizontally) { Text("♾️", fontSize = 48.sp); Text("GOJO FIGHTER", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold); Text("Train hard. Live better.", color = Muted) } } }
    PanelCard { Text("ACCOUNT & APP", color = Purple, fontWeight = FontWeight.Bold); Text("Workout sessions: $workouts", color = Color.White); Text("Theme: Black / Electric Purple", color = Muted); Text("Data is stored locally on this phone.", color = Muted, fontSize = 12.sp) }
}

@Composable fun MacroInput(label: String, value: String, onChange: (String)->Unit) { OutlinedTextField(value, onChange, label = { Text(label) }, singleLine = true, modifier = Modifier.fillMaxWidth(), colors = OutlinedTextFieldDefaults.colors(focusedTextColor=Color.White, unfocusedTextColor=Color.White, focusedBorderColor=Purple, unfocusedBorderColor=Muted, focusedLabelColor=Purple, unfocusedLabelColor=Muted)) }

@Composable fun SplashScreen() {
    Box(Modifier.fillMaxSize().background(Bg), contentAlignment = Alignment.Center) {
        Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(14.dp)) {
            Image(painterResource(R.drawable.gojo_logo), contentDescription = "GOJO AI FITNESS logo", modifier = Modifier.size(270.dp), contentScale = ContentScale.Fit)
            Text("TRAIN • TRACK • TRANSFORM", color = Purple, fontWeight = FontWeight.Bold, letterSpacing = 2.sp, fontSize = 12.sp)
            CircularProgressIndicator(color = Purple, strokeWidth = 3.dp, modifier = Modifier.size(26.dp))
        }
    }
}
