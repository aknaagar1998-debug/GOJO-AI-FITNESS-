# GOJO AI FITNESS — Fresh Android source project

Kotlin + Jetpack Compose MVP with a premium black/electric-purple theme, GOJO-inspired logo, splash screen, workout tracking, nutrition log, image-label meal scan, progress and profile.

## Easiest route using your existing GitHub repository (phone only)
1. Download `GOJO_AI_FITNESS_NEW_SOURCE.zip`.
2. Open your existing `GOJO-AI-FITNESS` repository on GitHub.
3. In the repository root, choose **Add file → Upload files**. Upload this ZIP with the exact name `GOJO_AI_FITNESS_NEW_SOURCE.zip`, replacing the old ZIP if GitHub asks.
4. Commit the change. Then edit `.github/workflows/main.yml`: change the ZIP name in the `unzip -q ... -d project` line to `GOJO_AI_FITNESS_NEW_SOURCE.zip`. Keep the existing `PROJECT_DIR` detection, build command `gradle --no-daemon -p "$PROJECT_DIR" assembleDebug`, and APK artifact path. Commit the workflow change to trigger the new build.
5. Open **Actions**, open the newest run, wait for green **Success**, then download `GOJO-AI-FITNESS-APK` under **Artifacts**. Extract the downloaded artifact ZIP and install the APK.

## Features and limitations in this MVP
- Home dashboard and bottom navigation.
- Workout exercise list and complete-workout counter.
- Nutrition totals for calories, protein, carbs and fat; editable estimates after scanning; water counter.
- Meal scan uses Android camera preview and on-device ML Kit general image labels. Labels are suggestions only; the app cannot reliably know hidden ingredients, cooking oil, exact portions or exact macros from one photo. Confirm/edit estimates before adding.
- Progress screen and profile. Local data uses SharedPreferences and may be lost if app data is cleared or app is uninstalled.
- AI meal scan here is on-device image labelling, not a cloud multimodal AI service. A more accurate food-specific nutrition service would need a separate food database/API and appropriate setup.

## Build requirements
Java 17, Gradle 8.9, Android Gradle Plugin 8.7.3, Android SDK 35.

The included anime-inspired logo is fan-style artwork. Before public/commercial distribution, use original commissioned artwork and check applicable intellectual-property permissions.
